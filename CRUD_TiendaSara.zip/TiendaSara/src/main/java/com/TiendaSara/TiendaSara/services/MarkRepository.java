package com.TiendaSara.TiendaSara.services;


import org.springframework.data.jpa.repository.JpaRepository;
import com.TiendaSara.TiendaSara.models.Mark;


public interface MarkRepository extends JpaRepository<Mark, Integer>{
    
}
